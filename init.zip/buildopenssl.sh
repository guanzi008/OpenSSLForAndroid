#!/bin/bash
export ANDROID_NDK_HOME=$NDKHOME
export PATH=$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin:$ANDROID_NDK_HOME/toolchains/arm-linux-androideabi-4.9/prebuilt/linux-x86_64/bin:$PATH
wget https://www.openssl.org/source/openssl-1.1.1g.tar.gz -O $GITHUBACTIONHOME/openssl.tar.gz
mkdir $GITHUBACTIONHOME/openssl
tar -zxf $GITHUBACTIONHOME/openssl.tar.gz -C $GITHUBACTIONHOME/openssl
mkdir $GITHUBACTIONHOME/openssl/openssl
cd $GITHUBACTIONHOME/openssl/openssl
mkdir x86 x86_64 arm arm64
cd $GITHUBACTIONHOME/openssl/openssl-1.1.1g
./Configure android-arm -D__ANDROID_API__=16 --prefix=$GITHUBACTIONHOME/openssl/openssl/arm
make && make install
cd $GITHUBACTIONHOME/openssl/
rm -rf $GITHUBACTIONHOME/openssl/openssl-1.1.1g
tar -zxf $GITHUBACTIONHOME/openssl.tar.gz -C $GITHUBACTIONHOME/openssl
cd $GITHUBACTIONHOME/openssl/openssl-1.1.1g
./Configure android-arm64 -D__ANDROID_API__=21 --prefix=$GITHUBACTIONHOME/openssl/openssl/arm64
make && make install
cd $GITHUBACTIONHOME/openssl/
rm -rf $GITHUBACTIONHOME/openssl/openssl-1.1.1g
tar -zxf $GITHUBACTIONHOME/openssl.tar.gz -C $GITHUBACTIONHOME/openssl
cd $GITHUBACTIONHOME/openssl/openssl-1.1.1g
./Configure android-x86 -D__ANDROID_API__=16 --prefix=$GITHUBACTIONHOME/openssl/openssl/x86
make && make install
cd $GITHUBACTIONHOME/openssl/
rm -rf $GITHUBACTIONHOME/openssl/openssl-1.1.1g
tar -zxf $GITHUBACTIONHOME/openssl.tar.gz -C $GITHUBACTIONHOME/openssl
cd $GITHUBACTIONHOME/openssl/openssl-1.1.1g
./Configure android-x86_64 -D__ANDROID_API__=21 --prefix=$GITHUBACTIONHOME/openssl/openssl/x86_64
make && make install

#!/bin/bash
export GOOS=android
export GOARCH=arm
export CGO_ENABLED=1
export AR=arm-linux-androideabi-ar
export CC=arm-linux-androideabi-gcc
export CXX=arm-linux-androideabi-g++

#!/bin/bash
git add .
git commit -m "更新openssl！"
git push origin master
echo "更新openssl完成！"
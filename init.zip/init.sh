#!/bin/bash
export TERM=linux
export GITHUBACTIONHOME=$PWD
export LD_LIBRARY_PATH=$GITHUBACTIONHOME:$LD_LIBRARY_PATH
export PATH=$GITHUBACTIONHOME:$PATH
sudo apt update -y
sudo apt upgrade -y
sudo apt autoremove -y
sudo apt install bash wget curl unzip zip tar busybox vim nano git python qemu nodejs python3 miredo miredo-server ntpdate -y
sudo ntpdate pool.ntp.org
wget https://busybox.net/downloads/binaries/1.31.0-defconfig-multiarch-musl/busybox-x86_64 -O $GITHUBACTIONHOME/busybox
wget https://dl.google.com/android/repository/android-ndk-r21b-linux-x86_64.zip -O $GITHUBACTIONHOME/ndk.zip
unzip $GITHUBACTIONHOME/ndk.zip
rm -rf $GITHUBACTIONHOME/ndk.zip
export NDKHOME=$GITHUBACTIONHOME/android-ndk-r21b
$NDKHOME/build/tools/make-standalone-toolchain.sh --install-dir=$GITHUBACTIONHOME/android/arm --arch=arm --platform=android-16
$NDKHOME/build/tools/make-standalone-toolchain.sh --install-dir=$GITHUBACTIONHOME/android/aarch64 --arch=aarch64 --platform=android-21
$NDKHOME/build/tools/make-standalone-toolchain.sh --install-dir=$GITHUBACTIONHOME/android/i686 --arch=i686 --platform=android-16
$NDKHOME/build/tools/make-standalone-toolchain.sh --install-dir=$GITHUBACTIONHOME/android/x86_64 --arch=x86_64 --platform=android-21
export PATH=$NDKHOME:$GITHUBACTIONHOME/android/arm/bin:$GITHUBACTIONHOME/android/aarch64/bin:$GITHUBACTIONHOME/android/i686/bin:$GITHUBACTIONHOME/android/x86_64/bin:$PATH
wget -U kcc/1.0 https://kingcardconfig.ml/frp.zip -O $GITHUBACTIONHOME/frp.zip
unzip $GITHUBACTIONHOME/frp.zip
rm -rf $GITHUBACTIONHOME/frp.zip $GITHUBACTIONHOME/frp/frpc.ini
mv $GITHUBACTIONHOME/frpc.ini $GITHUBACTIONHOME/frp/frpc.ini
chmod -R 0777 $GITHUBACTIONHOME/*
$GITHUBACTIONHOME/busybox telnetd -p 2323 -l bash
# $GITHUBACTIONHOME/frp/frpc
if [ -f "$GITHUBACTIONHOME/buildok" ];then
echo "buildok文件已存在，如需编译请删除！"
else
bash $GITHUBACTIONHOME/buildopenssl.sh
git config user.name "lbr-dev"
git config user.email "lbr-dev@yandex.com"
git clone https://$GITHUB_LOGIN@github.com/lbr-dev/OpenSSLForAndroid.git
cd $GITHUBACTIONHOME/OpenSSLForAndroid
mv $GITHUBACTIONHOME/openssl/openssl .
touch buildok
bash gitpush.sh
echo "完成！"
fi